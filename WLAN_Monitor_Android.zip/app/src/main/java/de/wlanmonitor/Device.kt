package de.wlanmonitor

data class Device(
    val ipInt: Int,
    val ip: String,
    val hostname: String?,
    val mac: String?,
    val latencyMs: Long?,
    val openPorts: List<Int>,
    val method: String,
    val isSelf: Boolean,
    val isGateway: Boolean
) {
    /** Grobe Vermutung anhand von Rolle und offenen Ports. */
    fun guessType(): String? = when {
        isSelf -> "Dieses Gerät"
        isGateway -> "Router / Gateway"
        62078 in openPorts -> "vermutlich Apple-Gerät (iPhone/iPad)"
        8008 in openPorts -> "vermutlich Chromecast / Google TV"
        631 in openPorts || 9100 in openPorts -> "vermutlich Drucker"
        554 in openPorts -> "vermutlich Kamera / Stream-Gerät"
        445 in openPorts || 139 in openPorts -> "vermutlich Computer / NAS (Dateifreigabe)"
        22 in openPorts -> "vermutlich Linux-Gerät / NAS (SSH)"
        openPorts.any { it in listOf(80, 443, 8080, 8443) } -> "Gerät mit Weboberfläche"
        else -> null
    }

    companion object {
        val PORT_NAMES = mapOf(
            22 to "SSH", 53 to "DNS", 80 to "HTTP", 139 to "NetBIOS", 443 to "HTTPS",
            445 to "SMB (Dateifreigabe)", 554 to "RTSP (Stream)", 631 to "IPP (Drucker)",
            8008 to "Chromecast", 8080 to "HTTP (alternativ)", 8443 to "HTTPS (alternativ)",
            9100 to "Druckdienst", 62078 to "Apple-Gerätesynchronisation"
        )
    }
}
