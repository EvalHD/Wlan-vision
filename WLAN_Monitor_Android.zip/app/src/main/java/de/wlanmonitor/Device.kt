package de.wlanmonitor

data class Device(
    val ipInt: Int,
    val ip: String,
    val hostname: String?,
    val mac: String?,
    val latencyMs: Long?,
    val openPorts: List<Int>,
    val method: String,
    val isSelf: Boolean,
    val isGateway: Boolean,
    val mdnsName: String? = null,
    val netbiosName: String? = null,
    val ssdpName: String? = null,
    val ssdpInfo: String? = null,
    val webTitle: String? = null,
    val webServer: String? = null,
    val customName: String? = null,
    val instanceName: String? = null,
    val services: List<String> = emptyList(),
    val banner: String? = null,
    val macNote: String? = null,
    val isNew: Boolean = false
) {
    /** Bester bekannter Name des Geräts. */
    fun displayName(): String? =
        customName ?: mdnsName ?: instanceName ?: hostname ?: netbiosName ?: ssdpName ?: webTitle

    /** Grobe Vermutung anhand von Rolle und offenen Ports. */
    fun guessType(): String? = when {
        isSelf -> "Dieses Gerät"
        isGateway -> "Router / Gateway"
        62078 in openPorts -> "vermutlich Apple-Gerät (iPhone/iPad)"
        7000 in openPorts -> "vermutlich AirPlay-Gerät (Apple TV, Lautsprecher)"
        8008 in openPorts || 8009 in openPorts -> "vermutlich Chromecast / Google TV"
        8123 in openPorts -> "vermutlich Home Assistant (Smart Home)"
        32400 in openPorts -> "vermutlich Plex-Server"
        631 in openPorts || 9100 in openPorts || 515 in openPorts -> "vermutlich Drucker"
        554 in openPorts -> "vermutlich Kamera / Stream-Gerät"
        3389 in openPorts -> "vermutlich Windows-PC (Remotedesktop)"
        5000 in openPorts || 5001 in openPorts -> "vermutlich Synology-NAS"
        445 in openPorts || 139 in openPorts -> "vermutlich Computer / NAS (Dateifreigabe)"
        1883 in openPorts || 8883 in openPorts -> "vermutlich Smart-Home-Gerät (MQTT)"
        5900 in openPorts -> "vermutlich Computer (VNC-Fernzugriff)"
        22 in openPorts -> "vermutlich Linux-Gerät / NAS (SSH)"
        openPorts.any { it in listOf(80, 443, 8000, 8080, 8081, 8443) } -> "Gerät mit Weboberfläche"
        else -> null
    }

    /** Eine Zeile für den Bericht. */
    fun summary(): String {
        val tag = when {
            isSelf -> " (dieses Gerät)"
            isGateway -> " (Router)"
            else -> ""
        }
        val parts = listOfNotNull(
            displayName(),
            ssdpInfo,
            guessType()?.takeIf { !isSelf && !isGateway },
            mac?.let { "MAC $it" },
            services.takeIf { it.isNotEmpty() }?.joinToString("/"),
            openPorts.takeIf { it.isNotEmpty() }?.let { "Ports " + it.joinToString(",") }
        )
        return ip + tag + (if (isNew) " [NEU]" else "") +
                (if (parts.isEmpty()) "" else " – " + parts.joinToString(" · "))
    }

    companion object {
        val PORT_NAMES = mapOf(
            21 to "FTP", 22 to "SSH", 23 to "Telnet", 25 to "SMTP (Mail)", 53 to "DNS",
            80 to "HTTP", 110 to "POP3 (Mail)", 139 to "NetBIOS", 143 to "IMAP (Mail)",
            443 to "HTTPS", 445 to "SMB (Dateifreigabe)", 515 to "LPD (Drucker)",
            554 to "RTSP (Stream)", 631 to "IPP (Drucker)", 1883 to "MQTT (Smart Home)",
            3389 to "RDP (Windows-Fernzugriff)", 5000 to "Synology / UPnP",
            5001 to "Synology HTTPS", 5900 to "VNC (Fernzugriff)", 7000 to "AirPlay",
            8000 to "HTTP (alternativ)", 8008 to "Chromecast", 8009 to "Chromecast (Cast)",
            8080 to "HTTP (alternativ)", 8081 to "HTTP (alternativ)", 8123 to "Home Assistant",
            8443 to "HTTPS (alternativ)", 8883 to "MQTT (verschlüsselt)", 9000 to "Webdienst",
            9100 to "Druckdienst", 32400 to "Plex", 49152 to "UPnP",
            62078 to "Apple-Gerätesynchronisation"
        )
    }
}
