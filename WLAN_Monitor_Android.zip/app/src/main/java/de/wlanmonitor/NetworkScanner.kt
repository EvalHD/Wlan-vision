package de.wlanmonitor

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.net.ConnectException
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

data class NetInfo(val ip: Int, val prefix: Int, val gateway: Int?, val isWifi: Boolean) {
    /** Zu scannendes Netz (mindestens /22, damit höchstens 1024 Adressen). */
    fun cidr(): String {
        val p = maxOf(22, minOf(prefix, 30))
        val net = ip and (-1 shl (32 - p))
        return "${NetworkScanner.intToIp(net)}/$p"
    }
}

data class ScanRange(val network: Int, val prefix: Int, val hosts: List<Int>)

object NetworkScanner {

    private val PORTS = listOf(22, 53, 80, 139, 443, 445, 554, 631, 8008, 8080, 8443, 9100, 62078)
    private val QUICK_PORTS = listOf(80, 443, 53, 22, 445, 62078)

    fun intToIp(i: Int): String =
        "${(i ushr 24) and 255}.${(i ushr 16) and 255}.${(i ushr 8) and 255}.${i and 255}"

    private fun addrToInt(a: Inet4Address): Int {
        val b = a.address
        return ((b[0].toInt() and 255) shl 24) or ((b[1].toInt() and 255) shl 16) or
                ((b[2].toInt() and 255) shl 8) or (b[3].toInt() and 255)
    }

    fun detect(ctx: Context): NetInfo? {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return null
        val net = cm.activeNetwork ?: return null
        val lp = cm.getLinkProperties(net) ?: return null
        val la = lp.linkAddresses.firstOrNull { it.address is Inet4Address } ?: return null
        val gw = lp.routes.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway
        val wifi = cm.getNetworkCapabilities(net)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        return NetInfo(
            addrToInt(la.address as Inet4Address),
            la.prefixLength,
            (gw as? Inet4Address)?.let { addrToInt(it) },
            wifi
        )
    }

    fun parseCidr(text: String): ScanRange? {
        val m = Regex("""^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})/(\d{1,2})$""")
            .matchEntire(text.trim()) ?: return null
        val o = (1..4).map { m.groupValues[it].toInt() }
        if (o.any { it > 255 }) return null
        val prefix = m.groupValues[5].toInt()
        if (prefix !in 22..30) return null
        val ip = (o[0] shl 24) or (o[1] shl 16) or (o[2] shl 8) or o[3]
        val net = ip and (-1 shl (32 - prefix))
        val size = 1 shl (32 - prefix)
        val hosts = (1 until size - 1).map { net + it }
        return ScanRange(net, prefix, hosts)
    }

    /**
     * Scannt alle Hosts parallel. Callbacks laufen im aufrufenden (Main-)Kontext.
     */
    suspend fun scan(
        hosts: List<Int>,
        selfIp: Int?,
        gateway: Int?,
        onProgress: (Int) -> Unit,
        onFound: (Device) -> Unit
    ) = coroutineScope {
        val sem = Semaphore(100)
        var done = 0
        hosts.map { ip ->
            async {
                val d = if (ip == selfIp) null else sem.withPermit { probe(ip, gateway) }
                done++
                onProgress(done)
                if (d != null) onFound(d)
            }
        }.awaitAll()
    }

    private suspend fun probe(ipInt: Int, gateway: Int?): Device? = withContext(Dispatchers.IO) {
        val ip = intToIp(ipInt)
        val addr = try {
            InetAddress.getByName(ip)
        } catch (e: Exception) {
            return@withContext null
        }
        val t0 = SystemClock.elapsedRealtime()
        var alive = try { addr.isReachable(700) } catch (e: Exception) { false }
        val latency = if (alive) SystemClock.elapsedRealtime() - t0 else null
        var method = if (alive) "Ping" else ""
        val open = mutableListOf<Int>()

        for (p in if (alive) PORTS else QUICK_PORTS) {
            try {
                Socket().use { it.connect(InetSocketAddress(addr, p), 250) }
                open.add(p)
                if (!alive) { alive = true; method = "TCP-Verbindung" }
            } catch (e: ConnectException) {
                // "Connection refused" = Gerät hat geantwortet, Port ist nur geschlossen
                val msg = (e.message ?: "").lowercase()
                if (!alive && (msg.contains("refused") || msg.contains("econnrefused"))) {
                    alive = true
                    method = "TCP (Port geschlossen)"
                }
            } catch (e: Exception) {
                // Timeout o. Ä.: keine Antwort
            }
        }
        if (!alive) return@withContext null

        val host = try {
            addr.canonicalHostName.takeIf { it != ip }
        } catch (e: Exception) {
            null
        }
        Device(ipInt, ip, host, null, latency, open, method, false, ipInt == gateway)
    }

    /** MAC-Adressen: Android 10+ sperrt den Zugriff für normale Apps meist. */
    fun readMacs(): Map<String, String> {
        val map = HashMap<String, String>()
        try {
            File("/proc/net/arp").readLines().drop(1).forEach { line ->
                val p = line.trim().split(Regex("\\s+"))
                if (p.size >= 4 && p[3] != "00:00:00:00:00:00" && p[3].contains(":")) {
                    map[p[0]] = p[3].lowercase()
                }
            }
        } catch (e: Exception) { }
        if (map.isEmpty()) {
            try {
                val proc = Runtime.getRuntime().exec(arrayOf("ip", "neigh", "show"))
                val text = proc.inputStream.bufferedReader().readText()
                val rx = Regex("""(\d{1,3}(?:\.\d{1,3}){3}).*lladdr\s+([0-9a-fA-F:]{17})""")
                text.lines().forEach { l ->
                    rx.find(l)?.let { map[it.groupValues[1]] = it.groupValues[2].lowercase() }
                }
            } catch (e: Exception) { }
        }
        return map
    }

    fun selfDevice(ip: Int, gateway: Int?): Device =
        Device(ip, intToIp(ip), Build.MODEL, null, 0, emptyList(), "Eigenes Gerät", true, ip == gateway)
}
