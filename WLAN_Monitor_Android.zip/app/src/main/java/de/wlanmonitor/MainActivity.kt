package de.wlanmonitor

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.wifi.WifiManager
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import de.wlanmonitor.databinding.ActivityMainBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val adapter = DeviceAdapter { showDetails(it) }
    private var scanJob: Job? = null
    private var autoJob: Job? = null
    private var lastAutoCidr: String? = null
    private val found = mutableListOf<Device>()
    private val prefs by lazy { getSharedPreferences("names", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.tvStatus.text = "Noch kein Scan durchgeführt."

        refreshNetworkInfo()

        b.btnScan.setOnClickListener { startScan() }
        b.swAuto.setOnCheckedChangeListener { _, on ->
            autoJob?.cancel()
            if (on) {
                autoJob = lifecycleScope.launch {
                    while (true) {
                        if (scanJob?.isActive != true) startScan()
                        delay(60_000)
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshNetworkInfo()
    }

    private fun nameOf(ip: String): String? = prefs.getString("name_$ip", null)

    private fun wifiLine(): String? {
        return try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                ?: return null
            @Suppress("DEPRECATION")
            val ci = wm.connectionInfo ?: return null
            if (ci.rssi <= -127) return null
            val ghz = when {
                ci.frequency > 5900 -> "6"
                ci.frequency > 4900 -> "5"
                else -> "2,4"
            }
            "Signal ${ci.rssi} dBm · ${ci.linkSpeed} Mbit/s · $ghz GHz"
        } catch (e: Exception) {
            null
        }
    }

    private fun refreshNetworkInfo() {
        val net = NetworkScanner.detect(this)
        if (net == null) {
            b.tvInfo.text = "Kein Netzwerk erkannt. Bitte mit dem WLAN verbinden."
            return
        }
        // Feld automatisch aktualisieren, solange der Nutzer es nicht selbst geändert hat
        val current = b.etCidr.text.toString().trim()
        if (current.isEmpty() || current == lastAutoCidr) {
            b.etCidr.setText(net.cidr())
            lastAutoCidr = net.cidr()
        }
        val gw = net.gateway?.let { " · Router: ${NetworkScanner.intToIp(it)}" } ?: ""
        val wifi = if (net.isWifi) wifiLine()?.let { "\n$it" } ?: "" else "\nHinweis: Aktuell kein WLAN aktiv."
        b.tvInfo.text = "Dieses Gerät: ${NetworkScanner.intToIp(net.ip)}$gw$wifi"
    }

    private fun startScan() {
        if (scanJob?.isActive == true) return
        refreshNetworkInfo()
        val net = NetworkScanner.detect(this)
        val range = NetworkScanner.parseCidr(b.etCidr.text.toString())
        if (range == null) {
            Toast.makeText(
                this,
                "Bitte ein Netz mit 22–30 Bits angeben, z. B. 192.168.1.0/24",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val selfIp = net?.ip?.takeIf { it in range.hosts }
        found.clear()
        if (selfIp != null) {
            found.add(
                NetworkScanner.selfDevice(selfIp, net?.gateway)
                    .copy(customName = nameOf(NetworkScanner.intToIp(selfIp)))
            )
        }
        adapter.submit(found.toList())

        b.progress.visibility = View.VISIBLE
        b.progress.max = range.hosts.size
        b.progress.progress = 0
        b.btnScan.isEnabled = false

        scanJob = lifecycleScope.launch {
            try {
                NetworkScanner.scan(
                    range.hosts, selfIp, net?.gateway,
                    onProgress = { done ->
                        b.progress.progress = done
                        b.tvStatus.text = "Scanne … $done/${range.hosts.size} · ${found.size} Geräte"
                    },
                    onFound = { d ->
                        found.add(d.copy(customName = nameOf(d.ip)))
                        found.sortBy { it.ipInt }
                        adapter.submit(found.toList())
                    }
                )

                b.tvStatus.text = "Lese Details aus … (${found.size} Geräte)"
                val macs = NetworkScanner.readMacs()
                val ssdpJob = async { Enricher.ssdp() }
                val jobs = found.toList().map { d ->
                    async { if (d.isSelf) d else Enricher.enrich(d) }
                }
                val ssdp = ssdpJob.await()
                val result = jobs.awaitAll().map { d ->
                    val s = ssdp[d.ip]
                    d.copy(mac = macs[d.ip], ssdpName = s?.name, ssdpInfo = s?.info)
                }
                found.clear()
                found.addAll(result)
                adapter.submit(found.toList())

                val time = SimpleDateFormat("HH:mm:ss", Locale.GERMANY).format(Date())
                b.tvStatus.text = "Fertig: ${found.size} Geräte gefunden · $time"
            } finally {
                b.progress.visibility = View.GONE
                b.btnScan.isEnabled = true
            }
        }
    }

    private fun showDetails(d: Device) {
        val sb = StringBuilder()
        sb.append("IP-Adresse: ").append(d.ip).append('\n')
        d.customName?.let { sb.append("Eigener Name: ").append(it).append('\n') }
        d.mdnsName?.let { sb.append("Name (Bonjour): ").append(it).append('\n') }
        d.hostname?.let { sb.append("Name (DNS): ").append(it).append('\n') }
        d.netbiosName?.let { sb.append("Name (Windows): ").append(it).append('\n') }
        d.ssdpName?.let { sb.append("Name (UPnP): ").append(it).append('\n') }
        if (d.displayName() == null) sb.append("Name: nicht bekannt\n")
        d.ssdpInfo?.let { sb.append("Hersteller/Modell: ").append(it).append('\n') }
        d.guessType()?.let { sb.append("Typ: ").append(it).append('\n') }
        d.webTitle?.let { sb.append("Weboberfläche: ").append(it).append('\n') }
        d.webServer?.let { sb.append("Webserver: ").append(it).append('\n') }
        sb.append("MAC-Adresse: ")
            .append(d.mac ?: "nicht verfügbar (Android blockiert den Zugriff ab Version 10)")
            .append('\n')
        sb.append("Erkannt per: ").append(d.method).append('\n')
        if (!d.isSelf) d.latencyMs?.let { sb.append("Antwortzeit: ").append(it).append(" ms\n") }
        if (d.openPorts.isNotEmpty()) {
            sb.append("\nOffene Ports:\n")
            d.openPorts.forEach { p ->
                sb.append("  ").append(p)
                Device.PORT_NAMES[p]?.let { sb.append(" – ").append(it) }
                sb.append('\n')
            }
        } else if (!d.isSelf) {
            sb.append("\nKeine der geprüften Ports offen.")
        }
        AlertDialog.Builder(this)
            .setTitle(d.displayName() ?: d.ip)
            .setMessage(sb.toString())
            .setPositiveButton("Schließen", null)
            .setNeutralButton("IP kopieren") { _, _ ->
                val cm = getSystemService(ClipboardManager::class.java)
                cm?.setPrimaryClip(ClipData.newPlainText("IP", d.ip))
                Toast.makeText(this, "IP kopiert", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Umbenennen") { _, _ -> renameDialog(d) }
            .show()
    }

    private fun renameDialog(d: Device) {
        val et = EditText(this)
        et.hint = "Eigener Name"
        et.setSingleLine()
        et.setText(d.customName ?: "")
        AlertDialog.Builder(this)
            .setTitle("Gerät benennen (${d.ip})")
            .setView(et)
            .setPositiveButton("Speichern") { _, _ ->
                val n = et.text.toString().trim()
                val edit = prefs.edit()
                if (n.isEmpty()) edit.remove("name_${d.ip}") else edit.putString("name_${d.ip}", n)
                edit.apply()
                for (i in found.indices) {
                    if (found[i].ip == d.ip) found[i] = found[i].copy(customName = n.ifEmpty { null })
                }
                adapter.submit(found.toList())
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }
}
