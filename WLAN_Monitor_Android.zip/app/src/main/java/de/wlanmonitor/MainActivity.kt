package de.wlanmonitor

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import de.wlanmonitor.databinding.ActivityMainBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val adapter = DeviceAdapter { showDetails(it) }
    private var scanJob: Job? = null
    private var autoJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.tvStatus.text = "Noch kein Scan durchgeführt."

        refreshNetworkInfo()

        b.btnScan.setOnClickListener { startScan() }
        b.swAuto.setOnCheckedChangeListener { _, on ->
            autoJob?.cancel()
            if (on) {
                autoJob = lifecycleScope.launch {
                    while (true) {
                        if (scanJob?.isActive != true) startScan()
                        delay(60_000)
                    }
                }
            }
        }
    }

    private fun refreshNetworkInfo() {
        val net = NetworkScanner.detect(this)
        if (net == null) {
            b.tvInfo.text = "Kein Netzwerk erkannt. Bitte mit dem WLAN verbinden."
            return
        }
        if (b.etCidr.text.isNullOrBlank()) b.etCidr.setText(net.cidr())
        val gw = net.gateway?.let { " · Router: ${NetworkScanner.intToIp(it)}" } ?: ""
        val warn = if (net.isWifi) "" else "\nHinweis: Aktuell kein WLAN aktiv."
        b.tvInfo.text = "Dieses Gerät: ${NetworkScanner.intToIp(net.ip)}$gw$warn"
    }

    private fun startScan() {
        if (scanJob?.isActive == true) return
        refreshNetworkInfo()
        val net = NetworkScanner.detect(this)
        val range = NetworkScanner.parseCidr(b.etCidr.text.toString())
        if (range == null) {
            Toast.makeText(
                this,
                "Bitte ein Netz mit 24–30 Bits angeben, z. B. 192.168.1.0/24",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val selfIp = net?.ip?.takeIf { it in range.hosts }
        val found = mutableListOf<Device>()
        if (selfIp != null) found.add(NetworkScanner.selfDevice(selfIp, net.gateway))
        adapter.submit(found.toList())

        b.progress.visibility = View.VISIBLE
        b.progress.max = range.hosts.size
        b.progress.progress = 0
        b.btnScan.isEnabled = false

        scanJob = lifecycleScope.launch {
            try {
                NetworkScanner.scan(
                    range.hosts, selfIp, net?.gateway,
                    onProgress = { done ->
                        b.progress.progress = done
                        b.tvStatus.text = "Scanne … $done/${range.hosts.size} · ${found.size} Geräte"
                    },
                    onFound = { d ->
                        found.add(d)
                        found.sortBy { it.ipInt }
                        adapter.submit(found.toList())
                    }
                )
                val macs = NetworkScanner.readMacs()
                val withMac = found.map { d -> d.copy(mac = macs[d.ip]) }
                adapter.submit(withMac)
                found.clear()
                found.addAll(withMac)
                val time = SimpleDateFormat("HH:mm:ss", Locale.GERMANY).format(Date())
                b.tvStatus.text = "Fertig: ${found.size} Geräte gefunden · $time"
            } finally {
                b.progress.visibility = View.GONE
                b.btnScan.isEnabled = true
            }
        }
    }

    private fun showDetails(d: Device) {
        val sb = StringBuilder()
        sb.append("IP-Adresse: ").append(d.ip).append('\n')
        sb.append("Name: ").append(d.hostname ?: "nicht bekannt").append('\n')
        d.guessType()?.let { sb.append("Typ: ").append(it).append('\n') }
        sb.append("MAC-Adresse: ")
            .append(d.mac ?: "nicht verfügbar (Android blockiert den Zugriff ab Version 10)")
            .append('\n')
        sb.append("Erkannt per: ").append(d.method).append('\n')
        if (!d.isSelf) d.latencyMs?.let { sb.append("Antwortzeit: ").append(it).append(" ms\n") }
        if (d.openPorts.isNotEmpty()) {
            sb.append("\nOffene Ports:\n")
            d.openPorts.forEach { p ->
                sb.append("  ").append(p)
                Device.PORT_NAMES[p]?.let { sb.append(" – ").append(it) }
                sb.append('\n')
            }
        } else if (!d.isSelf) {
            sb.append("\nKeine der geprüften Ports offen.")
        }
        AlertDialog.Builder(this)
            .setTitle(d.hostname ?: d.ip)
            .setMessage(sb.toString())
            .setPositiveButton("Schließen", null)
            .setNeutralButton("IP kopieren") { _, _ ->
                val cm = getSystemService(ClipboardManager::class.java)
                cm?.setPrimaryClip(ClipData.newPlainText("IP", d.ip))
                Toast.makeText(this, "IP kopiert", Toast.LENGTH_SHORT).show()
            }
            .show()
    }
}
