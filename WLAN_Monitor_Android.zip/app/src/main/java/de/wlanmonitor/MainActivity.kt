package de.wlanmonitor

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import de.wlanmonitor.databinding.ActivityMainBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val adapter = DeviceAdapter { showDetails(it) }
    private var scanJob: Job? = null
    private var autoJob: Job? = null
    private var lastAutoCidr: String? = null
    private var detectedCidr: String? = null
    private val found = mutableListOf<Device>()
    private val prefs by lazy { getSharedPreferences("names", Context.MODE_PRIVATE) }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            refreshNetworkInfo()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.tvStatus.text = "Noch kein Scan durchgeführt."

        b.etCidr.doAfterTextChanged { updateSuggest() }
        b.tvSuggest.setOnClickListener {
            detectedCidr?.let { c ->
                b.etCidr.setText(c)
                lastAutoCidr = c
            }
        }
        b.tvPermHint.setOnClickListener {
            permLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        b.btnShare.setOnClickListener { shareReport() }
        b.btnScan.setOnClickListener { startScan() }
        b.swAuto.setOnCheckedChangeListener { _, on ->
            autoJob?.cancel()
            if (on) {
                autoJob = lifecycleScope.launch {
                    while (true) {
                        if (scanJob?.isActive != true) startScan()
                        delay(60_000)
                    }
                }
            }
        }

        if (!hasLocation() && !prefs.getBoolean("asked", false)) {
            prefs.edit().putBoolean("asked", true).apply()
            permLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        refreshNetworkInfo()
        // Eigenes Netz erkannt: gleich einmal scannen
        if (NetworkScanner.detect(this) != null) startScan()
    }

    override fun onResume() {
        super.onResume()
        refreshNetworkInfo()
    }

    private fun nameOf(ip: String): String? = prefs.getString("name_$ip", null)

    private fun hasLocation() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED

    // ---------- WLAN-Infos ----------

    private fun wifiInfo(): WifiInfo? {
        return try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                ?: return null
            @Suppress("DEPRECATION")
            val ci = wm.connectionInfo ?: return null
            if (ci.rssi <= -127) null else ci
        } catch (e: Exception) {
            null
        }
    }

    private fun currentBssid(): String? =
        wifiInfo()?.bssid?.lowercase()?.takeIf { it.isNotBlank() && it != "02:00:00:00:00:00" }

    private fun bandOf(f: Int): String? = when {
        f in 2400..2500 -> "2,4 GHz (Kanal ${if (f == 2484) 14 else (f - 2407) / 5})"
        f in 4900..5900 -> "5 GHz (Kanal ${(f - 5000) / 5})"
        f in 5925..7125 -> "6 GHz (Kanal ${(f - 5950) / 5})"
        else -> null
    }

    private fun quality(rssi: Int) = when {
        rssi >= -50 -> "sehr gut"
        rssi >= -60 -> "gut"
        rssi >= -70 -> "mittel"
        else -> "schwach"
    }

    private fun buildInfo(net: NetInfo): String {
        val lines = mutableListOf<String>()
        val ci = wifiInfo()
        if (net.isWifi && ci != null) {
            val ssid = ci.ssid?.removeSurrounding("\"")
                ?.takeIf { it.isNotBlank() && it != "<unknown ssid>" }
            val std = if (Build.VERSION.SDK_INT >= 30) {
                when (ci.wifiStandard) {
                    4 -> "Wi-Fi 4"
                    5 -> "Wi-Fi 5"
                    6 -> "Wi-Fi 6"
                    8 -> "Wi-Fi 7"
                    else -> null
                }
            } else null
            lines.add(
                "WLAN: " + listOfNotNull(ssid ?: "Name nicht verfügbar", std, bandOf(ci.frequency))
                    .joinToString(" · ")
            )
            lines.add("Signal: ${ci.rssi} dBm (${quality(ci.rssi)}) · ${ci.linkSpeed} Mbit/s")
        } else if (!net.isWifi) {
            lines.add("Hinweis: Aktuell kein WLAN aktiv.")
        }
        val mask = NetworkScanner.intToIp(-1 shl (32 - net.prefix))
        lines.add("Dieses Gerät: ${NetworkScanner.intToIp(net.ip)}/${net.prefix} (Maske $mask)")
        net.gateway?.let { gw ->
            lines.add(
                "Router: ${NetworkScanner.intToIp(gw)}" +
                        (currentBssid()?.let { " · MAC $it" } ?: "")
            )
        }
        net.dhcp?.let { lines.add("DHCP-Server: $it") }
        if (net.dns.isNotEmpty()) lines.add("DNS: " + net.dns.joinToString(", "))
        net.ipv6.firstOrNull()?.let { lines.add("IPv6: $it") }
        if (net.mtu > 0) lines.add("MTU: ${net.mtu}")
        return lines.joinToString("\n")
    }

    private fun refreshNetworkInfo() {
        val net = NetworkScanner.detect(this)
        if (net == null) {
            detectedCidr = null
            b.tvInfo.text = "Kein Netzwerk erkannt. Bitte mit dem WLAN verbinden."
            b.tvPermHint.visibility = View.GONE
            updateSuggest()
            return
        }
        val detected = net.cidr()
        detectedCidr = detected
        // Feld automatisch aktualisieren, solange der Nutzer es nicht selbst geändert hat
        val current = b.etCidr.text.toString().trim()
        if (current.isEmpty() || current == lastAutoCidr) {
            b.etCidr.setText(detected)
            lastAutoCidr = detected
        }
        b.tvInfo.text = buildInfo(net)
        b.tvPermHint.visibility = if (net.isWifi && !hasLocation()) View.VISIBLE else View.GONE
        updateSuggest()
    }

    private fun updateSuggest() {
        val d = detectedCidr
        val cur = b.etCidr.text.toString().trim()
        if (d != null && cur != d) {
            b.tvSuggest.text = "Erkanntes Netz: $d – tippen zum Übernehmen"
            b.tvSuggest.visibility = View.VISIBLE
        } else {
            b.tvSuggest.visibility = View.GONE
        }
    }

    // ---------- Scan ----------

    private fun addFound(ipInt: Int, method: String, gw: Int?) {
        if (found.any { it.ipInt == ipInt }) return
        val ip = NetworkScanner.intToIp(ipInt)
        found.add(
            Device(
                ipInt, ip, null, null, null, emptyList(), method, false, ipInt == gw,
                customName = nameOf(ip)
            )
        )
    }

    private fun markNew(list: List<Device>, key: String): List<Device> {
        val known = prefs.getStringSet("known_$key", null)
        val ips = list.map { it.ip }.toSet()
        val result = if (known == null) list else list.map {
            if (it.ip !in known && !it.isSelf) it.copy(isNew = true) else it
        }
        prefs.edit().putStringSet("known_$key", HashSet((known ?: emptySet<String>()) + ips)).apply()
        return result
    }

    private fun startScan() {
        if (scanJob?.isActive == true) return
        refreshNetworkInfo()
        val net = NetworkScanner.detect(this)
        val range = NetworkScanner.parseCidr(b.etCidr.text.toString())
        if (range == null) {
            Toast.makeText(
                this,
                "Bitte ein Netz mit 22–30 Bits angeben, z. B. 192.168.1.0/24",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val gw = net?.gateway
        val selfIp = net?.ip?.takeIf { it in range.hosts }
        val key = NetworkScanner.intToIp(range.network) + "_" + range.prefix
        found.clear()
        if (selfIp != null) {
            found.add(
                NetworkScanner.selfDevice(selfIp, gw)
                    .copy(customName = nameOf(NetworkScanner.intToIp(selfIp)))
            )
        }
        adapter.submit(found.toList())

        b.progress.visibility = View.VISIBLE
        b.progress.max = range.hosts.size
        b.progress.progress = 0
        b.btnScan.isEnabled = false

        scanJob = lifecycleScope.launch {
            try {
                // 1. Alle Adressen anpingen
                NetworkScanner.scan(
                    range.hosts, selfIp, gw,
                    onProgress = { done ->
                        b.progress.progress = done
                        b.tvStatus.text = "Scanne … $done/${range.hosts.size} · ${found.size} Geräte"
                    },
                    onFound = { d ->
                        found.add(d.copy(customName = nameOf(d.ip)))
                        found.sortBy { it.ipInt }
                        adapter.submit(found.toList())
                    }
                )

                // 2. Per UPnP und Bonjour nach weiteren Geräten suchen
                b.tvStatus.text = "Suche per UPnP und Bonjour … (${found.size} Geräte)"
                val ssdpJob = async { Enricher.ssdp() }
                val mdnsJob = async { Enricher.mdnsDiscover() }
                val ssdp = ssdpJob.await()
                val mdns = mdnsJob.await()
                val hostSet = range.hosts.toHashSet()
                for (s in ssdp.responders) {
                    val i = NetworkScanner.ipStrToInt(s)
                    if (i != null && i in hostSet) addFound(i, "UPnP-Antwort", gw)
                }
                for (s in mdns.keys) {
                    val i = NetworkScanner.ipStrToInt(s)
                    if (i != null && i in hostSet) addFound(i, "Bonjour-Antwort", gw)
                }
                if (gw != null && gw in hostSet) {
                    addFound(gw, "Router laut Netzwerkeinstellungen", gw)
                }
                found.sortBy { it.ipInt }
                adapter.submit(found.toList())

                // 3. Details zu jedem Gerät auslesen
                b.tvStatus.text = "Lese Details aus … (${found.size} Geräte)"
                val macs = NetworkScanner.readMacs()
                val bssid = currentBssid()
                val jobs = found.toList().map { d ->
                    async { if (d.isSelf) d else Enricher.enrich(d) }
                }
                val enriched = jobs.awaitAll().map { d ->
                    val s = ssdp.infos[d.ip]
                    val m = mdns[d.ip]
                    var mac = macs[d.ip] ?: d.mac
                    var note: String? = d.macNote
                    if (mac == null && d.isGateway && bssid != null) {
                        mac = bssid
                        note = "WLAN-Zugangspunkt"
                    }
                    d.copy(
                        mac = mac,
                        macNote = note,
                        ssdpName = s?.name ?: d.ssdpName,
                        ssdpInfo = s?.info ?: d.ssdpInfo,
                        instanceName = m?.names?.firstOrNull(),
                        services = m?.services?.sorted() ?: emptyList()
                    )
                }
                val result = markNew(enriched, key)
                found.clear()
                found.addAll(result)
                adapter.submit(found.toList())

                val time = SimpleDateFormat("HH:mm:ss", Locale.GERMANY).format(Date())
                val neu = found.count { it.isNew }
                val neuText = if (neu > 0) " · $neu neu" else ""
                b.tvStatus.text = "Fertig: ${found.size} Geräte gefunden$neuText · $time"
            } finally {
                b.progress.visibility = View.GONE
                b.btnScan.isEnabled = true
            }
        }
    }

    // ---------- Details, Umbenennen, Teilen ----------

    private fun showDetails(d: Device) {
        val sb = StringBuilder()
        sb.append("IP-Adresse: ").append(d.ip).append('\n')
        if (d.isNew) sb.append("Neu im Netz (beim letzten Scan noch nicht gesehen)\n")
        d.customName?.let { sb.append("Eigener Name: ").append(it).append('\n') }
        d.mdnsName?.let { sb.append("Name (Bonjour): ").append(it).append('\n') }
        d.instanceName?.let { sb.append("Gerätename (Dienst): ").append(it).append('\n') }
        d.hostname?.let { sb.append("Name (DNS): ").append(it).append('\n') }
        d.netbiosName?.let { sb.append("Name (Windows): ").append(it).append('\n') }
        d.ssdpName?.let { sb.append("Name (UPnP): ").append(it).append('\n') }
        if (d.displayName() == null) sb.append("Name: nicht bekannt\n")
        d.ssdpInfo?.let { sb.append("Hersteller/Modell: ").append(it).append('\n') }
        d.guessType()?.let { sb.append("Typ: ").append(it).append('\n') }
        if (d.services.isNotEmpty()) {
            sb.append("Dienste: ").append(d.services.joinToString(", ")).append('\n')
        }
        d.webTitle?.let { sb.append("Weboberfläche: ").append(it).append('\n') }
        d.webServer?.let { sb.append("Webserver: ").append(it).append('\n') }
        d.banner?.let { sb.append("Dienst-Kennung: ").append(it).append('\n') }
        sb.append("MAC-Adresse: ")
        if (d.mac != null) {
            sb.append(d.mac)
            d.macNote?.let { sb.append(" (").append(it).append(')') }
        } else {
            sb.append("nicht verfügbar (Android blockiert den Zugriff ab Version 10)")
        }
        sb.append('\n')
        sb.append("Erkannt per: ").append(d.method).append('\n')
        if (!d.isSelf) d.latencyMs?.let { sb.append("Antwortzeit: ").append(it).append(" ms\n") }
        if (d.openPorts.isNotEmpty()) {
            sb.append("\nOffene Ports:\n")
            d.openPorts.forEach { p ->
                sb.append("  ").append(p)
                Device.PORT_NAMES[p]?.let { sb.append(" – ").append(it) }
                sb.append('\n')
            }
        } else if (!d.isSelf) {
            sb.append("\nKeine der geprüften Ports offen.")
        }
        AlertDialog.Builder(this)
            .setTitle(d.displayName() ?: d.ip)
            .setMessage(sb.toString())
            .setPositiveButton("Schließen", null)
            .setNeutralButton("IP kopieren") { _, _ ->
                val cm = getSystemService(ClipboardManager::class.java)
                cm?.setPrimaryClip(ClipData.newPlainText("IP", d.ip))
                Toast.makeText(this, "IP kopiert", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Umbenennen") { _, _ -> renameDialog(d) }
            .show()
    }

    private fun renameDialog(d: Device) {
        val et = EditText(this)
        et.hint = "Eigener Name"
        et.setSingleLine()
        et.setText(d.customName ?: "")
        AlertDialog.Builder(this)
            .setTitle("Gerät benennen (${d.ip})")
            .setView(et)
            .setPositiveButton("Speichern") { _, _ ->
                val n = et.text.toString().trim()
                val edit = prefs.edit()
                if (n.isEmpty()) edit.remove("name_${d.ip}") else edit.putString("name_${d.ip}", n)
                edit.apply()
                for (i in found.indices) {
                    if (found[i].ip == d.ip) found[i] = found[i].copy(customName = n.ifEmpty { null })
                }
                adapter.submit(found.toList())
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun shareReport() {
        if (found.isEmpty()) {
            Toast.makeText(this, "Noch keine Geräte gefunden", Toast.LENGTH_SHORT).show()
            return
        }
        val time = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMANY).format(Date())
        val sb = StringBuilder()
        sb.append("WLAN Monitor – Bericht ").append(time).append('\n')
        sb.append("Netz: ").append(b.etCidr.text).append('\n')
        sb.append(b.tvInfo.text).append("\n\n")
        sb.append("Geräte (").append(found.size).append("):\n")
        found.forEach { sb.append("• ").append(it.summary()).append('\n') }
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, sb.toString())
        }
        startActivity(Intent.createChooser(i, "Bericht teilen"))
    }
}
