package de.wlanmonitor

import android.os.SystemClock
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL

data class SsdpInfo(val name: String?, val info: String?)

/** Liest zusätzliche Infos von gefundenen Geräten aus (alles ohne Root). */
object Enricher {

    suspend fun enrich(d: Device): Device = coroutineScope {
        val mdns = async { mdnsName(d.ip) }
        val nb = async { netbiosName(d.ip) }
        val webPort = when {
            80 in d.openPorts -> 80
            8080 in d.openPorts -> 8080
            else -> null
        }
        val web: Deferred<Pair<String?, String?>>? =
            if (webPort != null) async { httpInfo(d.ip, webPort) } else null
        val w = web?.await()
        d.copy(
            mdnsName = mdns.await(),
            netbiosName = nb.await(),
            webTitle = w?.first,
            webServer = w?.second
        )
    }

    // ---------- mDNS / Bonjour: Gerät direkt nach seinem Namen fragen ----------

    private suspend fun mdnsName(ip: String): String? = withContext(Dispatchers.IO) {
        try {
            val q = ByteArrayOutputStream()
            q.write(byteArrayOf(0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0))
            val reversed = ip.split(".").reversed().joinToString(".") + ".in-addr.arpa"
            reversed.split(".").forEach { label ->
                val bytes = label.toByteArray()
                q.write(bytes.size)
                q.write(bytes)
            }
            q.write(0)
            q.write(byteArrayOf(0, 12, 0, 1)) // PTR, IN
            val data = q.toByteArray()
            DatagramSocket().use { s ->
                s.soTimeout = 800
                s.send(DatagramPacket(data, data.size, InetAddress.getByName(ip), 5353))
                val buf = ByteArray(1500)
                val pkt = DatagramPacket(buf, buf.size)
                s.receive(pkt)
                parseFirstPtr(buf, pkt.length)?.removeSuffix(".local")?.takeIf { it.isNotBlank() }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun readName(buf: ByteArray, start: Int): Pair<String, Int> {
        val sb = StringBuilder()
        var pos = start
        var end = -1
        var guard = 0
        while (guard++ < 50) {
            val len = buf[pos].toInt() and 255
            if (len == 0) {
                if (end < 0) end = pos + 1
                break
            }
            if ((len and 0xC0) == 0xC0) {
                val ptr = ((len and 0x3F) shl 8) or (buf[pos + 1].toInt() and 255)
                if (end < 0) end = pos + 2
                pos = ptr
                continue
            }
            sb.append(String(buf, pos + 1, len, Charsets.UTF_8)).append('.')
            pos += len + 1
        }
        return sb.toString().trimEnd('.') to (if (end < 0) pos else end)
    }

    private fun parseFirstPtr(buf: ByteArray, length: Int): String? {
        if (length < 12) return null
        val qd = ((buf[4].toInt() and 255) shl 8) or (buf[5].toInt() and 255)
        val an = ((buf[6].toInt() and 255) shl 8) or (buf[7].toInt() and 255)
        var pos = 12
        repeat(qd) {
            pos = readName(buf, pos).second + 4
        }
        repeat(an) {
            pos = readName(buf, pos).second
            val type = ((buf[pos].toInt() and 255) shl 8) or (buf[pos + 1].toInt() and 255)
            val rdLen = ((buf[pos + 8].toInt() and 255) shl 8) or (buf[pos + 9].toInt() and 255)
            pos += 10
            if (type == 12) return readName(buf, pos).first
            pos += rdLen
        }
        return null
    }

    // ---------- NetBIOS: Namen von Windows-PCs, NAS, Druckern ----------

    private suspend fun netbiosName(ip: String): String? = withContext(Dispatchers.IO) {
        try {
            val req = ByteArray(50)
            req[0] = 0x13
            req[1] = 0x37
            req[5] = 1
            req[12] = 0x20
            req[13] = 'C'.code.toByte()
            req[14] = 'K'.code.toByte()
            for (i in 15..44) req[i] = 'A'.code.toByte()
            req[45] = 0
            req[46] = 0
            req[47] = 0x21
            req[48] = 0
            req[49] = 1
            DatagramSocket().use { s ->
                s.soTimeout = 800
                s.send(DatagramPacket(req, req.size, InetAddress.getByName(ip), 137))
                val buf = ByteArray(1024)
                val pkt = DatagramPacket(buf, buf.size)
                s.receive(pkt)
                var pos = 12
                pos += if ((buf[pos].toInt() and 0xC0) == 0xC0) 2 else (buf[pos].toInt() and 255) + 2
                pos += 10
                val count = buf[pos].toInt() and 255
                pos++
                var result: String? = null
                for (i in 0 until count) {
                    val name = String(buf, pos, 15, Charsets.ISO_8859_1).trim()
                    val suffix = buf[pos + 15].toInt() and 255
                    val flags = ((buf[pos + 16].toInt() and 255) shl 8) or (buf[pos + 17].toInt() and 255)
                    pos += 18
                    if (suffix == 0 && (flags and 0x8000) == 0 && name.isNotEmpty()) {
                        result = name
                        break
                    }
                }
                result
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- Weboberfläche: Titel und Server auslesen ----------

    private fun readLimited(s: InputStream, max: Int): String {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(4096)
        var total = 0
        while (total < max) {
            val n = s.read(buf, 0, minOf(buf.size, max - total))
            if (n <= 0) break
            out.write(buf, 0, n)
            total += n
        }
        return out.toString("UTF-8")
    }

    private suspend fun httpInfo(ip: String, port: Int): Pair<String?, String?> =
        withContext(Dispatchers.IO) {
            var c: HttpURLConnection? = null
            try {
                c = URL("http://$ip:$port/").openConnection() as HttpURLConnection
                c.connectTimeout = 800
                c.readTimeout = 1200
                c.instanceFollowRedirects = false
                c.setRequestProperty("User-Agent", "WLANMonitor/1.0")
                val code = c.responseCode
                val server = c.getHeaderField("Server")?.take(60)
                val auth = c.getHeaderField("WWW-Authenticate") ?: ""
                val realm = Regex("realm=\"([^\"]+)\"").find(auth)?.groupValues?.get(1)
                val stream = if (code >= 400) c.errorStream else c.inputStream
                val body = if (stream != null) stream.use { readLimited(it, 16000) } else ""
                val title = Regex(
                    "<title[^>]*>(.*?)</title>",
                    setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
                ).find(body)?.groupValues?.get(1)
                    ?.replace(Regex("\\s+"), " ")?.trim()?.take(60)
                Pair(title?.takeIf { it.isNotEmpty() } ?: realm, server)
            } catch (e: Exception) {
                Pair<String?, String?>(null, null)
            } finally {
                c?.disconnect()
            }
        }

    // ---------- UPnP / SSDP: Hersteller und Modell (TVs, Router, Lautsprecher ...) ----------

    suspend fun ssdp(): Map<String, SsdpInfo> = withContext(Dispatchers.IO) {
        val locations = HashMap<String, String>()
        try {
            DatagramSocket().use { s ->
                s.soTimeout = 400
                val msg = ("M-SEARCH * HTTP/1.1\r\n" +
                        "HOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\n" +
                        "MX: 2\r\n" +
                        "ST: ssdp:all\r\n\r\n").toByteArray()
                val group = InetAddress.getByName("239.255.255.250")
                repeat(2) { s.send(DatagramPacket(msg, msg.size, group, 1900)) }
                val end = SystemClock.elapsedRealtime() + 3000
                val buf = ByteArray(2048)
                while (SystemClock.elapsedRealtime() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val text = String(p.data, 0, p.length)
                        val loc = Regex("(?im)^location:\\s*(\\S+)").find(text)?.groupValues?.get(1)
                        val ip = p.address.hostAddress
                        if (loc != null && ip != null && ip !in locations) locations[ip] = loc
                    } catch (e: SocketTimeoutException) {
                        // weiter warten
                    }
                }
            }
        } catch (e: Exception) {
            // kein SSDP möglich
        }
        val results = HashMap<String, SsdpInfo>()
        coroutineScope {
            locations.map { (ip, loc) ->
                async {
                    val info = fetchDescription(ip, loc)
                    if (info != null) synchronized(results) { results[ip] = info }
                }
            }.awaitAll()
        }
        results
    }

    private fun fetchDescription(ip: String, loc: String): SsdpInfo? {
        return try {
            val url = URL(loc)
            if (url.host != ip) return null // nur Beschreibungen vom antwortenden Gerät selbst
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 1000
            c.readTimeout = 1500
            val xml = c.inputStream.use { readLimited(it, 20000) }
            c.disconnect()
            fun tag(t: String): String? =
                Regex("<$t>(.*?)</$t>", RegexOption.DOT_MATCHES_ALL).find(xml)
                    ?.groupValues?.get(1)?.trim()?.take(60)?.takeIf { it.isNotEmpty() }
            val friendly = tag("friendlyName")
            val info = listOfNotNull(tag("manufacturer"), tag("modelName"))
                .joinToString(" ").ifEmpty { null }
            SsdpInfo(friendly, info)
        } catch (e: Exception) {
            null
        }
    }
}
