package de.wlanmonitor

import android.os.SystemClock
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URL

data class SsdpInfo(val name: String?, val info: String?)
data class SsdpResult(val infos: Map<String, SsdpInfo>, val responders: Set<String>)

class MdnsHit {
    val services = linkedSetOf<String>()
    val names = linkedSetOf<String>()
}

/** Liest zusätzliche Infos von gefundenen Geräten aus (alles ohne Root). */
object Enricher {

    private val portSem = Semaphore(150)

    private val FULL_PORTS = listOf(
        21, 22, 23, 25, 53, 80, 110, 139, 143, 443, 445, 515, 554, 631, 1883, 3389,
        5000, 5001, 5900, 7000, 8000, 8008, 8009, 8080, 8081, 8123, 8443, 8883, 9000,
        9100, 32400, 49152, 62078
    )

    private val MDNS_QUERIES = listOf(
        "_services._dns-sd._udp.local", "_airplay._tcp.local", "_googlecast._tcp.local",
        "_ipp._tcp.local", "_printer._tcp.local", "_smb._tcp.local",
        "_companion-link._tcp.local", "_hap._tcp.local", "_spotify-connect._tcp.local",
        "_http._tcp.local", "_workstation._tcp.local", "_raop._tcp.local"
    )

    private val SERVICE_LABELS = mapOf(
        "airplay" to "AirPlay", "raop" to "AirPlay-Audio", "googlecast" to "Chromecast",
        "ipp" to "Drucker (IPP)", "ipps" to "Drucker (IPP)", "printer" to "Drucker",
        "pdl-datastream" to "Drucker", "smb" to "Dateifreigabe (SMB)",
        "afpovertcp" to "Dateifreigabe (Apple)", "spotify-connect" to "Spotify Connect",
        "hap" to "HomeKit", "homekit" to "HomeKit", "http" to "Webdienst", "ssh" to "SSH",
        "workstation" to "Linux-Rechner", "companion-link" to "Apple-Gerät",
        "sleep-proxy" to "Apple (Sleep Proxy)", "matter" to "Matter", "hue" to "Philips Hue",
        "device-info" to "Geräteinfo"
    )

    suspend fun enrich(d: Device): Device = coroutineScope {
        val mdns = async { mdnsName(d.ip) }
        val dns = async { reverseDns(d.ip) }
        val nb = async { netbiosName(d.ip) }
        val ports = scanPorts(d.ip, d.openPorts).sorted()
        val webPort = when {
            80 in ports -> 80
            8080 in ports -> 8080
            8000 in ports -> 8000
            else -> null
        }
        val web: Deferred<Pair<String?, String?>>? =
            if (webPort != null) async { httpInfo(d.ip, webPort) } else null
        val bannerPort = when {
            22 in ports -> 22
            21 in ports -> 21
            else -> null
        }
        val ban: Deferred<String?>? =
            if (bannerPort != null) async { banner(d.ip, bannerPort) } else null
        val w = web?.await()
        d.copy(
            openPorts = ports,
            hostname = dns.await() ?: d.hostname,
            mdnsName = mdns.await(),
            netbiosName = nb.await(),
            webTitle = w?.first,
            webServer = w?.second,
            banner = ban?.await()
        )
    }

    // ---------- Ports (parallel, nur bei gefundenen Geräten) ----------

    private fun isOpen(addr: InetAddress, port: Int): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(addr, port), 300) }
        true
    } catch (e: Exception) {
        false
    }

    private suspend fun scanPorts(ip: String, known: List<Int>): List<Int> = coroutineScope {
        val addr = try {
            InetAddress.getByName(ip)
        } catch (e: Exception) {
            return@coroutineScope known
        }
        FULL_PORTS.map { p ->
            async(Dispatchers.IO) {
                if (p in known) p
                else portSem.withPermit { if (isOpen(addr, p)) p else null }
            }
        }.awaitAll().filterNotNull().let { (it + known).distinct() }
    }

    private suspend fun reverseDns(ip: String): String? = withContext(Dispatchers.IO) {
        try {
            InetAddress.getByName(ip).canonicalHostName.takeIf { it != ip }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun banner(ip: String, port: Int): String? = withContext(Dispatchers.IO) {
        try {
            Socket().use { s ->
                s.connect(InetSocketAddress(ip, port), 500)
                s.soTimeout = 700
                s.getInputStream().bufferedReader().readLine()?.trim()?.take(60)
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- gemeinsame DNS-Hilfen ----------

    private fun u16(buf: ByteArray, pos: Int): Int =
        ((buf[pos].toInt() and 255) shl 8) or (buf[pos + 1].toInt() and 255)

    private fun readName(buf: ByteArray, start: Int): Pair<String, Int> {
        val sb = StringBuilder()
        var pos = start
        var end = -1
        var guard = 0
        while (guard++ < 50) {
            val len = buf[pos].toInt() and 255
            if (len == 0) {
                if (end < 0) end = pos + 1
                break
            }
            if ((len and 0xC0) == 0xC0) {
                val ptr = ((len and 0x3F) shl 8) or (buf[pos + 1].toInt() and 255)
                if (end < 0) end = pos + 2
                pos = ptr
                continue
            }
            sb.append(String(buf, pos + 1, len, Charsets.UTF_8)).append('.')
            pos += len + 1
        }
        return sb.toString().trimEnd('.') to (if (end < 0) pos else end)
    }

    private fun buildQuery(name: String, type: Int, unicastBit: Boolean): ByteArray {
        val q = ByteArrayOutputStream()
        q.write(byteArrayOf(0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0))
        name.split(".").forEach { label ->
            val bytes = label.toByteArray()
            q.write(bytes.size)
            q.write(bytes)
        }
        q.write(0)
        q.write(type shr 8)
        q.write(type and 255)
        q.write(if (unicastBit) 0x80 else 0)
        q.write(1)
        return q.toByteArray()
    }

    // ---------- mDNS / Bonjour: Gerät direkt nach seinem Namen fragen ----------

    private suspend fun mdnsName(ip: String): String? = withContext(Dispatchers.IO) {
        try {
            val reversed = ip.split(".").reversed().joinToString(".") + ".in-addr.arpa"
            val data = buildQuery(reversed, 12, false)
            DatagramSocket().use { s ->
                s.soTimeout = 800
                s.send(DatagramPacket(data, data.size, InetAddress.getByName(ip), 5353))
                val buf = ByteArray(1500)
                val pkt = DatagramPacket(buf, buf.size)
                s.receive(pkt)
                parseFirstPtr(buf, pkt.length)?.removeSuffix(".local")?.takeIf { it.isNotBlank() }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parseFirstPtr(buf: ByteArray, length: Int): String? {
        if (length < 12) return null
        val qd = u16(buf, 4)
        val an = u16(buf, 6)
        var pos = 12
        repeat(qd) {
            pos = readName(buf, pos).second + 4
        }
        repeat(an) {
            pos = readName(buf, pos).second
            val type = u16(buf, pos)
            val rdLen = u16(buf, pos + 8)
            pos += 10
            if (type == 12) return readName(buf, pos).first
            pos += rdLen
        }
        return null
    }

    // ---------- mDNS-Suche im ganzen Netz: welche Dienste bieten Geräte an? ----------

    private fun serviceLabel(typeName: String): String {
        val first = typeName.substringBefore('.').removePrefix("_")
        return SERVICE_LABELS[first] ?: first
    }

    private fun handlePtr(name: String, target: String, hit: MdnsHit) {
        val n = name.lowercase()
        if (n == "_services._dns-sd._udp.local") {
            hit.services.add(serviceLabel(target))
        } else if (n.endsWith("._tcp.local") || n.endsWith("._udp.local")) {
            hit.services.add(serviceLabel(n))
            if (target.endsWith("." + name, ignoreCase = true)) {
                val inst = target.dropLast(name.length + 1).trim()
                if (inst.isNotEmpty()) hit.names.add(inst)
            }
        }
    }

    private fun parseMdns(buf: ByteArray, len: Int, hit: MdnsHit) {
        if (len < 12) return
        val qd = u16(buf, 4)
        val total = u16(buf, 6) + u16(buf, 8) + u16(buf, 10)
        var pos = 12
        repeat(qd) { pos = readName(buf, pos).second + 4 }
        repeat(total) {
            val (name, p) = readName(buf, pos)
            pos = p
            val type = u16(buf, pos)
            val rdLen = u16(buf, pos + 8)
            val rdStart = pos + 10
            if (type == 12) handlePtr(name, readName(buf, rdStart).first, hit)
            pos = rdStart + rdLen
        }
    }

    suspend fun mdnsDiscover(): Map<String, MdnsHit> = withContext(Dispatchers.IO) {
        val hits = HashMap<String, MdnsHit>()
        try {
            DatagramSocket().use { s ->
                s.soTimeout = 300
                val group = InetAddress.getByName("224.0.0.251")
                for (svc in MDNS_QUERIES) {
                    val q = buildQuery(svc, 12, true)
                    s.send(DatagramPacket(q, q.size, group, 5353))
                }
                val end = SystemClock.elapsedRealtime() + 3000
                val buf = ByteArray(4096)
                while (SystemClock.elapsedRealtime() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val ip = p.address.hostAddress
                        if (ip != null) {
                            val hit = hits.getOrPut(ip) { MdnsHit() }
                            try {
                                parseMdns(buf, p.length, hit)
                            } catch (e: Exception) {
                                // kaputtes Paket ignorieren
                            }
                        }
                    } catch (e: SocketTimeoutException) {
                        // weiter warten
                    }
                }
            }
        } catch (e: Exception) {
            // Multicast nicht möglich
        }
        hits
    }

    // ---------- NetBIOS: Namen von Windows-PCs, NAS, Druckern ----------

    private suspend fun netbiosName(ip: String): String? = withContext(Dispatchers.IO) {
        try {
            val req = ByteArray(50)
            req[0] = 0x13
            req[1] = 0x37
            req[5] = 1
            req[12] = 0x20
            req[13] = 'C'.code.toByte()
            req[14] = 'K'.code.toByte()
            for (i in 15..44) req[i] = 'A'.code.toByte()
            req[45] = 0
            req[46] = 0
            req[47] = 0x21
            req[48] = 0
            req[49] = 1
            DatagramSocket().use { s ->
                s.soTimeout = 800
                s.send(DatagramPacket(req, req.size, InetAddress.getByName(ip), 137))
                val buf = ByteArray(1024)
                val pkt = DatagramPacket(buf, buf.size)
                s.receive(pkt)
                var pos = 12
                pos += if ((buf[pos].toInt() and 0xC0) == 0xC0) 2 else (buf[pos].toInt() and 255) + 2
                pos += 10
                val count = buf[pos].toInt() and 255
                pos++
                var result: String? = null
                for (i in 0 until count) {
                    val name = String(buf, pos, 15, Charsets.ISO_8859_1).trim()
                    val suffix = buf[pos + 15].toInt() and 255
                    val flags = u16(buf, pos + 16)
                    pos += 18
                    if (suffix == 0 && (flags and 0x8000) == 0 && name.isNotEmpty()) {
                        result = name
                        break
                    }
                }
                result
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- Weboberfläche: Titel und Server auslesen ----------

    private fun readLimited(s: InputStream, max: Int): String {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(4096)
        var total = 0
        while (total < max) {
            val n = s.read(buf, 0, minOf(buf.size, max - total))
            if (n <= 0) break
            out.write(buf, 0, n)
            total += n
        }
        return out.toString("UTF-8")
    }

    private suspend fun httpInfo(ip: String, port: Int): Pair<String?, String?> =
        withContext(Dispatchers.IO) {
            var c: HttpURLConnection? = null
            try {
                c = URL("http://$ip:$port/").openConnection() as HttpURLConnection
                c.connectTimeout = 800
                c.readTimeout = 1200
                c.instanceFollowRedirects = false
                c.setRequestProperty("User-Agent", "WLANMonitor/1.0")
                val code = c.responseCode
                val server = c.getHeaderField("Server")?.take(60)
                val auth = c.getHeaderField("WWW-Authenticate") ?: ""
                val realm = Regex("realm=\"([^\"]+)\"").find(auth)?.groupValues?.get(1)
                val stream = if (code >= 400) c.errorStream else c.inputStream
                val body = if (stream != null) stream.use { readLimited(it, 16000) } else ""
                val title = Regex(
                    "<title[^>]*>(.*?)</title>",
                    setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
                ).find(body)?.groupValues?.get(1)
                    ?.replace(Regex("\\s+"), " ")?.trim()?.take(60)
                Pair(title?.takeIf { it.isNotEmpty() } ?: realm, server)
            } catch (e: Exception) {
                Pair<String?, String?>(null, null)
            } finally {
                c?.disconnect()
            }
        }

    // ---------- UPnP / SSDP: Hersteller und Modell (TVs, Router, Lautsprecher ...) ----------

    suspend fun ssdp(): SsdpResult = withContext(Dispatchers.IO) {
        val locations = HashMap<String, String>()
        val responders = HashSet<String>()
        try {
            DatagramSocket().use { s ->
                s.soTimeout = 400
                val msg = ("M-SEARCH * HTTP/1.1\r\n" +
                        "HOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\n" +
                        "MX: 2\r\n" +
                        "ST: ssdp:all\r\n\r\n").toByteArray()
                val group = InetAddress.getByName("239.255.255.250")
                repeat(2) { s.send(DatagramPacket(msg, msg.size, group, 1900)) }
                val end = SystemClock.elapsedRealtime() + 3000
                val buf = ByteArray(2048)
                while (SystemClock.elapsedRealtime() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val text = String(p.data, 0, p.length)
                        val loc = Regex("(?im)^location:\\s*(\\S+)").find(text)?.groupValues?.get(1)
                        val ip = p.address.hostAddress
                        if (ip != null) {
                            responders.add(ip)
                            if (loc != null && ip !in locations) locations[ip] = loc
                        }
                    } catch (e: SocketTimeoutException) {
                        // weiter warten
                    }
                }
            }
        } catch (e: Exception) {
            // kein SSDP möglich
        }
        val results = HashMap<String, SsdpInfo>()
        coroutineScope {
            locations.map { (ip, loc) ->
                async {
                    val info = fetchDescription(ip, loc)
                    if (info != null) synchronized(results) { results[ip] = info }
                }
            }.awaitAll()
        }
        SsdpResult(results, responders)
    }

    private fun fetchDescription(ip: String, loc: String): SsdpInfo? {
        return try {
            val url = URL(loc)
            if (url.host != ip) return null // nur Beschreibungen vom antwortenden Gerät selbst
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 1000
            c.readTimeout = 1500
            val xml = c.inputStream.use { readLimited(it, 20000) }
            c.disconnect()
            fun tag(t: String): String? =
                Regex("<$t>(.*?)</$t>", RegexOption.DOT_MATCHES_ALL).find(xml)
                    ?.groupValues?.get(1)?.trim()?.take(60)?.takeIf { it.isNotEmpty() }
            val friendly = tag("friendlyName")
            val info = listOfNotNull(tag("manufacturer"), tag("modelName"))
                .joinToString(" ").ifEmpty { null }
            SsdpInfo(friendly, info)
        } catch (e: Exception) {
            null
        }
    }
}
