package de.wlanmonitor

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import de.wlanmonitor.databinding.ItemDeviceBinding

class DeviceAdapter(private val onClick: (Device) -> Unit) :
    RecyclerView.Adapter<DeviceAdapter.VH>() {

    private var items: List<Device> = emptyList()

    fun submit(list: List<Device>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(val b: ItemDeviceBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemDeviceBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val d = items[position]
        val tag = when {
            d.isSelf -> " · Dieses Gerät"
            d.isGateway -> " · Router"
            else -> ""
        }
        h.b.tvIp.text = d.ip + tag
        h.b.tvName.text = d.displayName() ?: d.guessType() ?: "Unbekanntes Gerät"
        val parts = mutableListOf<String>()
        d.ssdpInfo?.let { parts.add(it) }
        d.mac?.let { parts.add("MAC $it") }
        d.latencyMs?.takeIf { !d.isSelf }?.let { parts.add("$it ms") }
        if (d.openPorts.isNotEmpty()) parts.add("Ports: " + d.openPorts.joinToString(", "))
        if (parts.isEmpty()) parts.add(d.method)
        h.b.tvMeta.text = parts.joinToString(" · ")
        h.itemView.setOnClickListener { onClick(d) }
    }
}
