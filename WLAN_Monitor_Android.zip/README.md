# WLAN Monitor (Android)

Zeigt Geräte in deinem eigenen WLAN: IP, Namen (Bonjour/DNS/Windows/UPnP), Hersteller und Modell (UPnP),
Webseiten-Titel, Antwortzeit, offene Ports, Typ-Vermutung sowie WLAN-Signal und Geschwindigkeit.
Geräte lassen sich selbst benennen (wird auf dem Handy gespeichert).
Antippen eines Geräts öffnet die Details. Optional automatischer Scan alle 60 Sekunden.

## Bauen über GitHub
1. Neues Repository auf github.com anlegen.
2. Diese ZIP-Datei (`WLAN_Monitor_Android.zip`) unverändert hochladen
   (Add file → Upload files → Commit).
3. Workflow anlegen: Add file → Create new file, Dateiname
   `.github/workflows/build-apk.yml` eintippen, den Inhalt der mitgelieferten
   `build-apk.yml` einfügen, Commit.
4. Reiter Actions → "APK bauen" läuft von selbst (oder "Run workflow").
5. Fertig: unter Releases (rechts im Repository) die Datei `WLAN-Monitor.apk`
   herunterladen und installieren. Alternativ im Lauf unter Artifacts.

Der Workflow entpackt die ZIP selbst und baut die App.

## Hinweise
- Nur Netzwerke scannen, die du selbst verwaltest.
- MAC-Adressen blockiert Android ab Version 10 für normale Apps, meist wird "nicht verfügbar" angezeigt.
- Geräte, die Ping und alle geprüften Ports blockieren, werden nicht gefunden.
