# WLAN Monitor (Android)

Zeigt Geräte in deinem eigenen WLAN: IP, Namen (Bonjour/DNS/Windows/UPnP), Hersteller und Modell (UPnP),
Webseiten-Titel, Antwortzeit, offene Ports, Typ-Vermutung sowie WLAN-Signal und Geschwindigkeit.
Geräte lassen sich selbst benennen (wird auf dem Handy gespeichert).
Antippen eines Geräts öffnet die Details. Optional automatischer Scan alle 60 Sekunden.

## Bauen über GitHub
1. Neues Repository auf github.com anlegen.
2. Diese ZIP-Datei (`WLAN_Monitor_Android.zip`) unverändert hochladen
   (Add file → Upload files → Commit).
3. Workflow anlegen: Add file → Create new file, Dateiname
   `.github/workflows/build-apk.yml` eintippen, den Inhalt der mitgelieferten
   `build-apk.yml` einfügen, Commit.
4. Reiter Actions → "APK bauen" läuft von selbst (oder "Run workflow").
5. Fertig: unter Releases (rechts im Repository) die Datei `WLAN-Monitor.apk`
   herunterladen und installieren. Alternativ im Lauf unter Artifacts.

Der Workflow entpackt die ZIP selbst und baut die App.

## Neu in dieser Version
- Erkennt das eigene Netz automatisch und schlägt es als Scan-Bereich vor (auch größere Netze ab /22).
- Scannt zusätzlich per UPnP und Bonjour/mDNS nach Geräten, die auf Ping/TCP nicht antworten.
- Deutlich mehr Infos je Gerät: Hersteller/Modell (UPnP), Bonjour-/Windows-/DNS-Name, angebotene Dienste
  (AirPlay, Chromecast, Drucker, SMB, SSH, HomeKit, Spotify Connect ...), Webseiten-Titel und -Server,
  Dienst-Kennung (Banner) bei SSH/FTP, alle gefundenen offenen Ports statt nur weniger.
- Zeigt WLAN-Name, Standard (Wi-Fi 4/5/6/7), Band/Kanal, Signalqualität, DNS-Server, DHCP-Server, IPv6, MTU.
- Markiert Geräte, die seit dem letzten Scan neu im Netz aufgetaucht sind.
- "Teilen"-Button erstellt einen Textbericht aller gefundenen Geräte zum Versenden/Speichern.
- Geräte lassen sich umbenennen (nur lokal auf dem Handy gespeichert).

## Hinweise
- Nur Netzwerke scannen, die du selbst verwaltest.
- MAC-Adressen blockiert Android ab Version 10 für normale Apps, meist wird "nicht verfügbar" angezeigt.
- Geräte, die Ping und alle geprüften Ports blockieren, werden nicht gefunden.
